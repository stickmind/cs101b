#include "RisingTides.h"
using namespace std;

Grid<bool> floodedRegionsIn(const Grid<double>& terrain,
                            const Vector<GridLocation>& sources,
                            double height) {
    /* TODO: Delete this line and the next four lines, then implement this function. */
    (void) terrain;
    (void) sources;
    (void) height;
    return {};
}
