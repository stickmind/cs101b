#ifndef SPL_BUILD_H
#define SPL_BUILD_H

#define SPL_VERSION "2024.1"
#define SPL_BUILD_DATE "2024/10/15"
#define SPL_BUILD_USER "StickMind"

#endif
