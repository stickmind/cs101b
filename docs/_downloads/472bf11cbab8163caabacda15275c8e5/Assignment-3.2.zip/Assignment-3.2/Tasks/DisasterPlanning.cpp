#include "DisasterPlanning.h"
using namespace std;

Optional<Set<string>> placeEmergencySupplies(const Map<string, Set<string>>& roadNetwork,
                                             int numCities) {
    /* TODO: Delete this comment and next few lines, then implement this function. */
    (void) roadNetwork;
    (void) numCities;
    return Nothing;
}
