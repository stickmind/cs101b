#include "WinSumLoseSum.h"
using namespace std;

Optional<Set<int>> makeTarget(const Set<int>& elems, int target) {
    /* TODO: Delete this comment and the next few lines, then implement this
     * function.
     */
    (void) elems;
    (void) target;
    return Nothing;
}
