#include "ShiftScheduling.h"
using namespace std;

int numSchedulesFor(const Set<Shift>& shifts, int maxHours) {
    /* TODO: Delete this comment and the lines below it, then implement
     * this function.
     */
    (void) shifts;
    (void) maxHours;
    return -1;
}

Set<Shift> maxProfitSchedule(const Set<Shift>& shifts, int maxHours) {
    /* TODO: Delete this comment and the lines below it, then implement
     * this function.
     */
    (void) shifts;
    (void) maxHours;
    return {};
}
