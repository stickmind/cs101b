/* File: Permutations.cpp
 *
 * Functions to list off all permutations of a collection of elements.
 */
#include <iostream>
#include <string>
#include "set.h"
#include "console.h"
using namespace std;

/* Given a string str of characters that haven't yet
 * been processed, and a string soFar of a permutation
 * built up to this point, list all permutations that
 * can be formed by extending the permutation in soFar
 * with the characters of str.
 */
void listPermutationsRec(const string& str,
                         const string& soFar) {
    /* Base case: If there are no characters left
     * to decide on, print out what we have.
     */
    if (str == "") {
        cout << soFar << endl;
    }
    /* Recursive case: If there are still choices
     * to make, choose which one comes next.
     */
    else {
        for (int i = 0; i < str.length(); i++) {
            listPermutationsRec(str.substr(0, i) + str.substr(i + 1),
                                soFar + str[i]);
        }
    }
}

/* Wrapper function: List all permutations of the string str.
 * This wrapper function solves a problem: listPermutationsRec
 * needs two arguments, but clients only need one. This function
 * serves as a bridge that lets clients just pass one argument
 * but let the recursive workhorse use two.
 */
void listPermutationsOf(const string& str) {
    listPermutationsRec(str, "");
}

/* Bonus content not covered in class! Here's how you would write
 * a recursive function that returns a set of all permutations of
 * a string, rather than just printing them to the console. It's
 * worth comparing this against the implementation above.
 */
Set<string> permutationsRec(const string& str, const string& soFar) {
    /* Base case: If we've used all characters up, then the only
     * permutation you can make is soFar. So we return a set consisting
     * purely of soFar.
     */
    if (str == "") {
        return { soFar };
    }
    /* Recursive case: If characters remain, then we choose each option
     * for what comes next and see what happens if we append it.
     */
    else {
        Set<string> result;
        for (int i = 0; i < str.length(); i++) {
            result += permutationsRec(str.substr(0, i) + str.substr(i + 1),
                                      soFar + str[i]);
        }
        return result;
    }
}

Set<string> permutationsOf(const string& str) {
    return permutationsRec(str, "");
}

int main() {
    listPermutationsOf("CAKE");
    cout << permutationsOf("YUM!") << endl;
    return 0;
}

