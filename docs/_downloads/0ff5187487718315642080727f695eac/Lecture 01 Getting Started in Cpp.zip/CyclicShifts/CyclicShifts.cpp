/* File: CyclicShifts.cpp
 *
 * A program that tests if two strings are cyclic shifts of
 * one another.
 */
#include <iostream>
#include <string>
#include "simpio.h"
#include "console.h"
using namespace std;

/* Given two strings, is one a rotation of the other? */
bool areCyclicallyEqual(string one, string two);

int main() {
    /* Get two strings from the user. */
    string one = getLine("First string:  ");
    string two = getLine("Second string: ");

    /* See if one rotates into the other. */
    if (areCyclicallyEqual(one, two)) {
        cout << "Yep!" << endl;
    } else {
        cout << "Nah." << endl;
    }

    return 0;
}

/* Given two strings, are they cyclic shifts of one another? */
bool areCyclicallyEqual(string one, string two) {
    /* Loop one fewer time than characters in the first string. */
    for (int i = 1; i < one.length(); i++) {
        /* If the strings match, great! We're done. */
        if (one == two) {
            return true;
        }

        /* Otherwise, rotate the second string by one position. */
        two = two.substr(1) + two[0];
    }

    /* Do one final check; there's a fencepost issue with one more
     * check needed than rotations.
     */
    return one == two;
}





