#include <iostream>
#include "console.h"
using namespace std;

/* Forward declaration (prototype) lets us call cheer() in main
 * before it's written.
 */
void cheer(int numTimes);

/* This is where things begin! */
int main() {
    cheer(3);
    return 0;
}

/* Cheers the indicated number of times. */
void cheer(int numTimes) {
    for (int i = 0; i < numTimes; i++) {
        cout << "Hip hip, hooray!" << endl;
    }
}
