#include "EeyOhrCaatr.h"
using namespace std;

string everyOtherCharacterOf(string input) {
    (void) input;
    return "";
}
