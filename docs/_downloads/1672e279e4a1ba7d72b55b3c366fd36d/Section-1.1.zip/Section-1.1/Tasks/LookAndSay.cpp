#include "LookAndSay.h"
using namespace std;

string lookAndSay(string number) {
    (void) number;
    return "";
}
