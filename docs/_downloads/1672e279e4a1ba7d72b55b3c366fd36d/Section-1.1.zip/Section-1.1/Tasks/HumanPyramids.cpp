#include "HumanPyramids.h"
#include "error.h"
using namespace std;

int peopleInPyramidOfHeight(int n) {
    (void) n;
    return 0;
}
