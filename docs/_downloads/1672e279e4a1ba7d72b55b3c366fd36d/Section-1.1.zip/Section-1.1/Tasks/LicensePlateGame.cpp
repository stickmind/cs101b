#include "LicensePlateGame.h"
#include "strlib.h"
using namespace std;

bool wordMatchesPlate(string word, string plate) {
    (void) word;
    (void) plate;
    return false;
}
