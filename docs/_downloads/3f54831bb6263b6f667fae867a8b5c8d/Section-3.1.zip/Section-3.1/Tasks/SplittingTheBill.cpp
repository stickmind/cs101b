#include "SplittingTheBill.h"
using namespace std;

void listPossiblePayments(int total, const Set<string>& people) {
    (void) total;
    (void) people;
}
