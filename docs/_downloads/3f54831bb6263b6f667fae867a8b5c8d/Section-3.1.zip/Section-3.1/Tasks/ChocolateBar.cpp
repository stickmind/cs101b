#include "ChocolateBar.h"
using namespace std;

int numWaysToEat(int numSquares) {
    /* Can't have a negative number of squares. */
    if (numSquares < 0) {
        error("Negative chocolate? YOU MONSTER!");
    }

    /* If we have zero or one square, there's exactly one way to eat
     * the chocolate.
     */
    if (numSquares <= 1) {
        return 1;
    }
    /* Otherwise, we either eat one square, leaving numSquares - 1 more
     * to eat, or we eat two squares, leaving numSquares - 2 to eat.
     */
    else {
        return numWaysToEat(numSquares - 1) +
               numWaysToEat(numSquares - 2);
    }
}

/* Print all ways to eat numSquares more squares, given that we've
 * already taken the bites given in soFar.
 */
void printWaysToEatRec(int numSquares, const Vector<int>& soFar) {
    /* Base Case: If there are no squares left, the only option is to use
     * the bites we've taken already in soFar.
     */
    if (numSquares == 0) {
        cout << soFar << endl;
    }
    /* Base Case: If there is one square lfet, the only option is to eat
     * that square.
     */
    else if (numSquares == 1) {
        cout << soFar + 1 << endl;
    }
    /* Otherwise, we take take bites of size one or of size two. */
    else {
        printWaysToEatRec(numSquares - 1, soFar + 1);
        printWaysToEatRec(numSquares - 2, soFar + 2);
    }
}

void printWaysToEat(int numSquares) {
    if (numSquares < 0) {
        error("You owe me some chocolate!");
    }

    /* We begin without having made any bites. */
    printWaysToEatRec(numSquares, {});
}

/* Returns all ways to eat numSquares more squares, given that we've
 * already taken the bites given in soFar.
 */
Set<Vector<int>> waysToEatRec(int numSquares, const Vector<int>& soFar) {
    /* Base Case: If there are no squares left, the only option is to use
     * the bites we've taken already in soFar.
     */
    if (numSquares == 0) {
        /* There is one option here, namely, the set of bites we came up
         * with in soFar. So if we return all the ways to eat the
         * chocolate bar given that we've committed to what's in soFar,
         * we should return a set with just one item, and that one item
         * should be soFar.
         */
        return { soFar };
    }
    /* Base Case: If there is one square lfet, the only option is to eat
     * that square.
     */
    else if (numSquares == 1) {
        /* Take what we have, and extend it by eating one more bite. */
        return { soFar + 1 };
    }
    /* Otherwise, we take take bites of size one or of size two. */
    else {
        /* Each individual recursive call returns a set containing the
         * possibilities that arise from exploring that choice. We want
         * to combine these together.
         */
        return waysToEatRec(numSquares - 1, soFar + 1) +
               waysToEatRec(numSquares - 2, soFar + 2);
    }
}

Set<Vector<int>> waysToEat(int numSquares) {
    if (numSquares < 0) {
        error("You owe me some chocolate!");
    }

    /* We begin without having made any bites. */
    return waysToEatRec(numSquares, {});
}
