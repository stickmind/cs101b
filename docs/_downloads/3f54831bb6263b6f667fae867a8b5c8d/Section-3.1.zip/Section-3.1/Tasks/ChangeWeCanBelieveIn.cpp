#include "ChangeWeCanBelieveIn.h"
#include "error.h"
using namespace std;

int fewestCoinsFor(int cents, const Set<int>& coins) {
    (void) cents;
    (void) coins;
    return -1;
}
