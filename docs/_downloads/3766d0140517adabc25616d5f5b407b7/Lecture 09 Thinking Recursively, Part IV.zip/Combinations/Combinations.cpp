#include <iostream>
#include "set.h"
#include "console.h"
using namespace std;

/* A quick rundown on the types here:
 *
 *   string:             An individual person
 *   Set<string>:        A group of people
 *   Set<Set<string>>:   Lots of possible groups of people
 *
 * Given a set of options and a number of additional people that need to
 * be chosen, returns all combinations of that many people that can be
 * formed, given that we have already committed to picking the folks in
 * soFar.
 */
Set<Set<string>> combinationsRec(const Set<string>& options,
                                 int numMoreToPick,
                                 const Set<string>& soFar) {
    /* Base Case 1: No choices remain. */
    if (numMoreToPick == 0) {
        return { soFar };
    }
    /* Base Case 2: Not enough people to satisfy the request. */
    if (numMoreToPick > options.size()) {
        return { };
    }
    /* Recursive case: Pick a person, then try including them
     * and excluding them.
     */
    auto person = options.first();
    auto remaining = options - person;

    /* First, EXCLUDE this person. */
    auto without = combinationsRec(remaining, numMoreToPick, soFar);

    /* Second, INCLUDE this person. */
    auto with = combinationsRec(remaining, numMoreToPick - 1, soFar + person);

    return with + without;

}

/* Wrapper function around combinationsRec that kicks off the recursion
 * with the last argument set to the empty set, since we haven't picked
 * anyone at the start.
 */
Set<Set<string>> combinationsOf(const Set<string>& options,
                                int numToPick) {
    return combinationsRec(options, numToPick, { });
}

/* Current members of the US Supreme Court, ordered
 * by seniority. (Or at least, they're ordered HERE
 * by seniority; the Set will order them internally
 * however it feels like it. ^_^)
 *
 * Fun fact: the most junior Associate Justice is
 * responsible for, among other things, opening the
 * door for the other justices and coordinating
 * what's in their cafeteria.
 *
 * Fun fact: The Chief Justice sits, ex officio,
 * on the Board of Regents of the Smithsonian
 * Institution. Job perks!
 */
const Set<string> usSupremeCourt = {
    "Roberts",
    "Thomas",
    "Alito",
    "Sotomayor",
    "Kagan",
    "Gorsuch",
    "Kavanaugh",
    "Barrett",
    "Jackson"
};

int main() {
    auto combinations = combinationsOf(usSupremeCourt, 3);

    cout << "There are " << combinations.size()
         << " combinations. They are: " << endl;

    for (auto combination: combinations) {
        cout << combination << endl;
    }
    return 0;
}
