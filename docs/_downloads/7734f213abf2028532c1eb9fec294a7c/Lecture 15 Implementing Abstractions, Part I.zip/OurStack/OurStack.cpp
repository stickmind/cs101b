/******************************************************************************
 * File: OurStack.cpp
 *
 * Implementation of the OurStack type.
 */

#include "OurStack.h"
#include "error.h"

/* Initial size for our stack. */
const int kInitialSize = 4;

OurStack::OurStack() {
    logicalSize   = 0;
    allocatedSize = kInitialSize;
    elems         = new int[kInitialSize];
}

void OurStack::push(int value) {
    /* Make sure we have space. */
    if (logicalSize == allocatedSize) {
        error("Too many sardines, not enough can.");
    }

    /* New element goes in the next free slot. */
    elems[logicalSize] = value;
    logicalSize++;
}

int OurStack::peek() const {
    /* Make sure there really is something here. */
    if (isEmpty()) {
        error("What is the sound of one hand clapping?");
    }

    return elems[logicalSize - 1];
}

int OurStack::pop() {
    /* Clever trick: peek() already finds the right element
     * and bounds-checks. Use it to figure out what the
     * correct answer is.
     */
    int result = peek();

    /* Pretend this element isn't here. */
    logicalSize--;
    return result;
}

bool OurStack::isEmpty() const {
    return size() == 0;
}

int OurStack::size() const {
    return logicalSize;
}
