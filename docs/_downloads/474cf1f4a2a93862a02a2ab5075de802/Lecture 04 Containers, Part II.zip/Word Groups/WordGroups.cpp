/* File: WordGroups.cpp
 *
 * A program that clusters words into groups based on their
 * first letter.
 */
#include <iostream>
#include <string>
#include "console.h"
#include "lexicon.h"
#include "simpio.h"
#include "strlib.h"
#include "map.h"
#include "set.h"
using namespace std;

int main() {
    Lexicon english("res/EnglishWords.txt");

    /* Divvy words up into different Lexicons by their first letter.
     * Each key is a letter; each value is a Lexicon of all words
     * starting with that letter.
     */
    Map<char, Lexicon> wordsByFirstLetter;
    for (string word: english) {
        /* Look up the Lexicon associated with the first letter of
         * this word, autoinserting if it's not already there, and
         * add this word to the Lexicon.
         */
        wordsByFirstLetter[word[0]] += word;
    }

    /* Print all words starting with q. */
    cout << wordsByFirstLetter['q'] << endl;

    return 0;
}




























