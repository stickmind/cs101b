/* File: Counter.cpp
 *
 * A program that remembers how many times each phrase has
 * been seen.
 */
#include <iostream>
#include <string>
#include "console.h"
#include "simpio.h"
#include "strlib.h"
#include "map.h"
using namespace std;

int main() {
    /* Map from strings to how many times we've see those strings. */
    Map<string, int> freqMap;

    while (true) {
        string text = getLine("Enter some text: ");
        
        /* If we've seen this before, this is its frequency. Otherwise,
         * map autoinsertion automagically puts it in for us.
         */
        cout << "Times seen: " << freqMap[text] << endl;
        freqMap[text]++;
    }
}




























