/* File: Tautonyms.cpp
 *
 * A program that finds all tautonyms in the English language.
 * (A tautonym is a string that consists of the same string
 * repeated twice.)
 */
#include <iostream>
#include <string>
#include "console.h"
#include "lexicon.h"
using namespace std;

/* Given a string, check if its first and second halves are the same. */
bool isTautonym(const string& word) {
    /* If the string doesn't have even length, it's definitely not
     * something repeated twice. (This check isn't strictly speaking
     * necessary.)
     */
    if (word.length() % 2 != 0) {
        return false;
    }

    /* Split the string into two halves and check if they're equal. */
    int half = word.length() / 2;
    return word.substr(0, half) == word.substr(half);
}

int main() {
    Lexicon english("res/EnglishWords.txt");

    for (string word: english) {
        if (isTautonym(word)) {
            cout << word << endl;
        }
    }
    return 0;
}




























