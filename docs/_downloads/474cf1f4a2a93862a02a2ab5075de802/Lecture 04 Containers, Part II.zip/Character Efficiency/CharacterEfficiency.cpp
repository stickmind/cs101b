/* File: CharacterEfficiency.cpp
 *
 * A program for finding the English word with the highest ratio
 * of length to number of distinct letters.
 */
#include <iostream>
#include <string>
#include "console.h"
#include "lexicon.h"
#include "strlib.h"
#include "set.h"
using namespace std;

/* Given a string, returns its character efficiency: the ratio
 * of the string length to the number of different characters.
 */
double efficiencyOf(const string& word) {
    /* Throw all the characters of the string into a set, which,
     * since sets don't hold duplicates, ends up holding one
     * copy of each distinct character of the string.
     */
    Set<char> letters;
    for (char ch: word) {
        letters += ch;
    }

    /* We have to cast one of these to a double to ensure we get
     * Real Division instead of Funny C++ Integer Division.
     */
    return double(word.length()) / letters.size();
}

int main() {
    Lexicon english("res/EnglishWords.txt");

    /* Best word we've seen thus far and its efficiency. */
    string bestWord;
    double bestEfficiency = 0;

    /* Compute the efficiency of each word and track the best. */
    for (string word: english) {
        double efficiency = efficiencyOf(word);

        if (efficiency > bestEfficiency) {
            bestWord = word;
            bestEfficiency = efficiency;
        }
    }

    cout << "The best word in English, by far, is " << bestWord << endl;
    cout << "Its efficiency is " << bestEfficiency << endl;
    cout << "Now you know. :-)" << endl;

    return 0;
}




























