#include "OurSet.h"
using namespace std;

const int kInitialBucketCount = 6; // Or really anything, really.

/********************************************
 * private:
 *    Vector<Vector<string>> buckets;
 *    HashFunction<string> hashFn;
 *    int numElems;
 */

OurSet::OurSet() {
    /* Create some buckets */
    for (int i = 0; i < kInitialBucketCount; i++) {
        buckets.add({ });
    }

    /* Pick a hash function */
    hashFn = forSize(kInitialBucketCount);

    /* Miscellaneous shenanigans */
    numElems = 0;
}

void OurSet::add(const string& value) {
    /* We're a set, so don't allow for duplicates. */
    if (contains(value)) return;

    /* Add this item to the correct bucket. */
    int bucket = hashFn(value);
    buckets[bucket] += value;
    
    /* Keep this in sync with the element count. */
    numElems++;
}

bool OurSet::contains(const string& value) const {
    /* Check if the correct bucket contains this item. */
    int bucket = hashFn(value);

    for (string elem: buckets[bucket]) {
        if (elem == value) return true;
    }

    return false;
}

/* Size is tracked separately from the number of buckets. */
int OurSet::size() const {
    return numElems;
}

/* We're empty if we have size zero. */
bool OurSet::isEmpty() const {
    return size() == 0;
}
