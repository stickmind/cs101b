#include "MountainsOfRecursia.h"
using namespace std;

Vector<Point> makeMountainRange(const Point& left,
                                const Point& right,
                                int amplitude,
                                double decayRate) {
    /* TODO: Delete this comment and the next few lines, then implement this
     * function.
     */
    (void) left;
    (void) right;
    (void) amplitude;
    (void) decayRate;
    return { };
}
