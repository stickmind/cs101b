#include "TempleOfRecursia.h"
using namespace std;

Vector<Rectangle> makeTemple(const Rectangle& bounds, const TempleParameters& params) {
    /* TODO: Delete this comment and the next few lines, then implement this function. */
    (void) bounds;
    (void) params;
    return { };
}
