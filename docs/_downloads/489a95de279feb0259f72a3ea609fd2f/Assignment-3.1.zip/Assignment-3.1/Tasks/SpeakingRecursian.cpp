#include "SpeakingRecursian.h"
using namespace std;

Vector<string> allRecursianWords(int numSyllables) {
    /* TODO: Delete this comment and the next few lines, then implement
     * this function.
     */
    (void) numSyllables;
    return { };
}
