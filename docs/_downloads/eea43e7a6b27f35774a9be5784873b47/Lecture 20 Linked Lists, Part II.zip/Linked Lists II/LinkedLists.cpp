/*************************************************
 * File: LinkedLists.cpp
 *
 * Our very second program using Linked Lists! :-D
 */

#include <iostream>
#include <string>
#include "simpio.h"
#include "console.h"
using namespace std;

/* Type: Cell
 *
 * A cell in a linked list.
 */
struct Cell {
    string value;
    Cell* next;
};

/* Given a linked list, how long is it? */
int lengthOf(Cell* list) {
    /* Base case: An empty list has length zero. */
    if (list == nullptr) return 0;

    /* Recursive case: The length is one, plus the length of the
     * remaining list.
     */
    return 1 + lengthOf(list->next);
}

/* From last time! */
void printList(Cell* list) {
    while (list != nullptr) {
        cout << "  " << list->value << endl;
        list = list->next;
    }
}

/* From last time! */
void freeList(Cell* list) {
    while (list != nullptr) {
        Cell* next = list->next;
        delete list;
        list = next;
    }
}

/* Prepends (puts at the front) a new element to the list. We take the
 * list parameter by reference because we need to change where the list
 * points.
 */
void prependTo(Cell*& list, const string& value) {
    Cell* cell  = new Cell;
    cell->value = value;
    cell->next  = list;
    list        = cell;
}

/* Appends (adds to the end) a new element to the list. This uses a tail
 * pointer so that we can efficiently jump to the last element of the list.
 */
void appendTo(Cell*& head, Cell*& tail, const string& value) {
    Cell* cell  = new Cell;
    cell->value = value;
    cell->next  = nullptr;

    /* List is empty. */
    if (head == nullptr) {
        tail = head = cell;
    } else {
        tail->next = cell;
        tail = cell;
    }
}

int main() {
    Cell* head = nullptr;
    Cell* tail = nullptr;
    appendTo(head, tail, "Elephant");
    appendTo(head, tail, "Sunfish");
    appendTo(head, tail, "Whale");
    appendTo(head, tail, "Piraracu");

    cout << "This list has length " << lengthOf(head) << "." << endl;
    printList(head);
    freeList(head);
    return 0;
}






