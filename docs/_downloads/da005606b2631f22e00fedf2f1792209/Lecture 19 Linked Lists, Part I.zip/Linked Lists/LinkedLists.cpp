/*************************************************
 * File: LinkedLists.cpp
 *
 * Our very first program using Linked Lists! :-D
 */

#include <iostream>
#include <string>
#include "simpio.h"
#include "console.h"
using namespace std;

/* Type: Cell
 *
 * A cell in a linked list.
 */
struct Cell {
    string value;
    Cell* next;
};

/* Creates and returns the linked list from the lecture slides:
 *
 * pudu -> quokka -> dikdik -> (nullptr)
 */
Cell* makeList() {
    Cell* list = new Cell;
    list->value = "pudu!";
    list->next = new Cell;
    list->next->value = "quokka!";
    list->next->next = new Cell;
    list->next->next->value = "dikdik!";
    list->next->next->next = nullptr;
    return list;
}

int lengthOf(Cell* list) {
    /* Base case: If the list is empty, it has length 0. */
    if (list == nullptr) return 0;

    /* Recursive case: We have the first cell. Measure the
     * length of the rest of the list.
     */
    return 1 + lengthOf(list->next);
}

void printList(Cell* list) {
    /* Walk forward, printing out cells, until we hit the end. */
    while (list != nullptr) {
        cout << list->value << endl;
        list = list->next;
    }
}

Cell* readList() {
    /* Get data from the user. */
    string entry = getLine("Enter next item, or RETURN if you're done.");
    
    /* If they don't want anything, give back an empty list. */
    if (entry == "") return nullptr;

    /* Otherwise, the data they gave us goes at the front of the list, and
     * we then recursively see what comes after us.
     */
    Cell* result  = new Cell;
    result->value = entry;
    result->next  = readList();

    return result;
}

void freeList(Cell* list) {
    while (list != nullptr) {
        /* We need this helper pointer to track where to go next, since we're
         * about to blow up the cell holding that info.
         */
        Cell* helper = list->next;
        delete list;
        list = helper;
    }
}

int main() {
    Cell* list = readList();
    cout << "This list has " << lengthOf(list) << " items." << endl;
    printList(list);
    freeList(list);
    return 0;
}
