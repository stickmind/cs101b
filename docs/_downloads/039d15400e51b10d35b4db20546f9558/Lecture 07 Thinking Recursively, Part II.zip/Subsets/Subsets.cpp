/* File: Subsets.cpp
 *
 * A program to list off all subsets of a master set.
 */
#include <iostream>
#include <string>
#include "set.h"
#include "vector.h"
#include "console.h"
using namespace std;

/* List all subsets of the set 'elems.' For each of those
 * subsets, also add the contents of soFar to that resulting
 * set.
 */
void listSubsetsOf(const Set<int>& elems,
                   const Set<int>& soFar) {
    /* Base case: If elems is empty, then we've already made
     * every decision that needs to be made. We have to then
     * list out the empty set, plus the elements in soFar.
     * That's the same as just printing out soFar.
     */
    if (elems.isEmpty()) {
        cout << soFar << endl;
    }
    /* Recursive case: If the set isn't empty, pick an
     * element out of the set - it doesn't matter how -
     * and then remove it. Now, you need to list the
     * subsets of what remains, twice: once with that
     * element added in, once without it added in.
     */
    else {
        int elem = elems.first();
        Set<int> remaining = elems - elem;

        /* List all sets that INCLUDE this element. */
        listSubsetsOf(remaining, soFar + elem);

        /* List all sets that EXCLUDE this element. */
        listSubsetsOf(remaining, soFar);
    }
}

int main() {
    listSubsetsOf({1, 2, 3, 4, 5, 6, 7, 8, 9, 10}, {});
    return 0;
}

