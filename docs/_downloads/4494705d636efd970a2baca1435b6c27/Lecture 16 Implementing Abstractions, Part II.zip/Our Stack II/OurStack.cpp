/******************************************************************************
 * File: OurStack.cpp
 *
 * Implementation (.cpp) file for OurStack.
 */

#include "OurStack.h"
#include "error.h"

/* Constant controlling the default size of our stack. */
const int kInitialSize = 4;

/* Constructor initializes the fields of the stack to
 * appropriate defaults.
 */
OurStack::OurStack() {
    logicalSize = 0;
    allocatedSize = kInitialSize;
    elems = new int[allocatedSize];
}

OurStack::~OurStack() {
    delete[] elems;
}

int OurStack::size() const {
    return logicalSize;
}

bool OurStack::isEmpty() const {
    return size() == 0;
}

void OurStack::push(int value) {
    /* Out of space? */
    if (allocatedSize == logicalSize) {
        grow();
    }

    /* Add the element. */
    elems[logicalSize] = value;
    logicalSize++;
}

int OurStack::peek() const {
    /* Nothing here? */
    if (isEmpty()) {
        error("What is the sound of one hand clapping?");
    }

    return elems[logicalSize - 1];
}

int OurStack::pop() {
    int result = peek();
    logicalSize--;
    return result;
}

void OurStack::grow() {
    /* Increase the size of the array. Doubling (actually,
     * multiplying the size by any number bigger than 1)
     * ensures that the amortized (average) cost of a push
     * is O(1).
     */
    allocatedSize *= 2;
    int* helper = new int[allocatedSize];

    /* Move elements out of the old array. */
    for (int i = 0; i < logicalSize; i++) {
        helper[i] = elems[i];
    }

    delete[] elems;
    elems = helper;
}






