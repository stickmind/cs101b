/* File: DigitalDigits.cpp
 *
 * A program that explores properties of digits of
 * numbers!
 */
#include <iostream>
#include "simpio.h"
#include "console.h"
using namespace std;

int sumOfDigitsOf(int n);

int main() {
    while (true) {
        int val = getInteger("For this trick, I need a number! ");
        cout << "Its digit sum is " << sumOfDigitsOf(val) << "." << endl << endl;
    }
}

/* Returns the sum of the digits of the number n, assuming n >= 0. */
int sumOfDigitsOf(int n) {
    /* Base Case: Single-digit numbers are their own digit sums. */
    if (n < 10) {
        return n;
    }
    /* Recursive Case: Given a multidigit number, split the number into
     * "everything but the last digit" and "the last digit." Then recursively
     * sum everything but the last digit, and add the last digit back in.
     */
    else {
        return sumOfDigitsOf(n / 10) + (n % 10);
    }
}


