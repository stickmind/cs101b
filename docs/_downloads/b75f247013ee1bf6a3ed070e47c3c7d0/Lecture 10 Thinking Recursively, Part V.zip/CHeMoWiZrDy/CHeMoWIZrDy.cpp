#include <iostream>
#include <string>
#include "set.h"
#include "strlib.h"
#include "lexicon.h"
#include "simpio.h"
#include "console.h"
#include "optional.h"
using namespace std;

/* All the elements. */
const Set<string> kAllElements = {
    "H",  "He", "Li", "Be", "B",
    "C",  "N",  "O",  "F",  "Ne",
    "Na", "Mg", "Al", "Si", "P",
    "S",  "Cl", "Ar", "K",  "Ca",
    "Sc", "Ti", "V",  "Cr", "Mn",
    "Fe", "Co", "Ni", "Cu", "Zn",
    "Ga", "Ge", "As", "Se", "Br",
    "Kr", "Rb", "Sr", "Y",  "Zr",
    "Nb", "Mo", "Tc", "Ru", "Rh",
    "Pd", "Ag", "Cd", "In", "Sn",
    "Sb", "Te", "I",  "Xe", "Cs",
    "Ba", "La", "Ce", "Pr", "Nd",
    "Pm", "Sm", "Eu", "Gd", "Tb",
    "Dy", "Ho", "Er", "Tm", "Yb",
    "Lu", "Hf", "Ta", "W",  "Re",
    "Os", "Ir", "Pt", "Au", "Hg",
    "Tl", "Pb", "Bi", "Po", "At",
    "Rn", "Fr", "Ra", "Ac", "Th",
    "Pa", "U",  "Np", "Pu", "Am",
    "Cm", "Bk", "Cf", "Es", "Fm",
    "Md", "No", "Lr", "Rf", "Db",
    "Sg", "Bh", "Hs", "Mt", "Ds",
    "Rg", "Cn", "Nh", "Fl", "Mc",
    "Lv", "Ts", "Og"
};

/* Given a string, finds a way to spell it with element symbols from the
 * periodic table, or returns that there's no way to do this.
 */
Optional<string> spellWithElements(const string& word) {
    /* Base case: We can spell the empty string. */
    if (word == "") {
        return word;
    }

    /* Recursive case: Some symbol comes next. Figure out
     * which one and try them all. We could make this more efficient
     * by trying prefixes of word to see which ones are elements
     * rather than scanning all element symbols, but this is fine
     * for our use case.
     */
    for (string element: kAllElements) {
        /* See if the word starts with this element symbol. We convert
         * each to lowercase here to avoid mismatches between mixed-case
         * words and element symbols.
         */
        if (startsWith(toLowerCase(word), toLowerCase(element))) {
            /* See if we can spell the rest of the word using element symbols.
             * If so, extend the smaller spelling into a larger one by
             * prepending the current element symbol.
             */
            auto result = spellWithElements(word.substr(element.length()));
            if (result != Nothing) {
                return element + result.value();
            }
        }
    }

    return Nothing;
}

int main() {
    Lexicon english("res/EnglishWords.txt");

    /* Find all element-spellable words of 15 or more characters. Why 15? Because
     * it's more fun that way. :-)
     */
    for (string word: english) {
        if (word.length() >= 15) {
            /* See if the word can be spelled with elements. */
            Optional<string> result = spellWithElements(word);
            if (result != Nothing) {
                cout << result << endl;
            }
        }
    }
    return 0;
}
