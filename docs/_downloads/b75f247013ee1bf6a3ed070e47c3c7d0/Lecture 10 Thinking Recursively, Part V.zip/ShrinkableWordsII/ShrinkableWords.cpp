#include <iostream>
#include <string>
#include "vector.h"
#include "lexicon.h"
#include "console.h"
#include "simpio.h"
#include "optional.h"
using namespace std;

/* Forms a Vector<string> showing how to shrink a word down to the empty string,
 * if there is a way to do so.
 */
Optional<Vector<string>> shrinkWord(const string& word, const Lexicon& english) {
    /* Base case: Something has to be a word to be a
     * shrinkable word.
     */
    if (!english.contains(word)) {
        return Nothing;
    }
    /* Base case: If length is one, we're done. */
    if (word.length() == 1) {
        return { word };
    }

    /* Recursive case: Try removing every character, one at a time,
     * to see if any one of them leaves us with a shrinkable word.
     */
    for (int i = 0; i < word.length(); i++) {
        auto shrunken = word.substr(0, i) + word.substr(i + 1);

        /* See if we can shrink the remaining word to nothing. If so,
         * extend that sequence by adding this word.
         */
        auto result = shrinkWord(shrunken, english);
        if (result != Nothing) {
            return result.value() + word;
        }
    }

    /* Oh fiddlesticks. */
    return Nothing;
}

int main() {
    Lexicon english("res/EnglishWords.txt");
    while (true) {
        string word = getLine("Enter a word: ");

        /* Find a shrinking sequence, if one exists. */
        Optional<Vector<string>> result = shrinkWord(word, english);
        if (result != Nothing) {
            cout << result << endl;
        } else {
            cout << "Nothing to see here, folks; move along." << endl;
        }
    }
}



