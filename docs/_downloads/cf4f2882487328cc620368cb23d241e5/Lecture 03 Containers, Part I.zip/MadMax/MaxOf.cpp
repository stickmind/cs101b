/* File: MaxOf.cpp
 *
 * A program showing off several ways to find the maximum element of a Vector.
 */
#include <iostream>
#include <algorithm> // For C++'s max function
#include "vector.h"
#include "console.h"
using namespace std;

int maxOf(const Vector<int>& elems);

int main() {
    Vector<int> v = { 137, 106, 107, 166,
                      103, 261, 109 };
    cout << maxOf(v) << endl;
    return 0;
}

/* Given a list of numbers, returns the largest number. Assumes the list
 * isn't empty; an empty list has no maximum element.
 */
int maxOf(const Vector<int>& elems) {
    /* Base case: If there's just one element, it's the maximum. */
    if (elems.size() == 1) {
        return elems[0];
    }
    /* Recursive case: The maximum value of the array is either the
     * first element, or it's the max element of what remains.
     */
    else {
        int first = elems[0];
        Vector<int> rest = elems.subList(1); // All but the first element
        return max(first, maxOf(rest));
    }
}

