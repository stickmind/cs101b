#include "TwoStackQueue.h"
#include "error.h"
using namespace std;

void TwoStackQueue::enqueue(int value) {
    (void) value;
}

int TwoStackQueue::dequeue() {
    return -1;
}

int TwoStackQueue::size() const {
    return -1;
}

bool TwoStackQueue::isEmpty() const {
    return false;
}
