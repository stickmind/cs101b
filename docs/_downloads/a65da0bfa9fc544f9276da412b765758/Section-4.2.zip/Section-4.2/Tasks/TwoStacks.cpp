#include "TwoStacks.h"
#include "error.h"
using namespace std;

const int kInitialSize = 10; // Matching the images from above

TwoStacks::TwoStacks() {

}

TwoStacks::~TwoStacks() {

}

void TwoStacks::pushFirst(int value) {
    (void) value;
}

void TwoStacks::pushSecond(int value) {
    (void) value;
}

int TwoStacks::peekFirst() const {
    return -1;
}

int TwoStacks::peekSecond() const {
    return -1;
}

int TwoStacks::popFirst() {
    return -1;
}

int TwoStacks::popSecond() {
    return -1;
}

int TwoStacks::sizeFirst() const {
    return -1;
}

int TwoStacks::sizeSecond() const {
    return -1;
}

bool TwoStacks::isFirstEmpty() const {
    return false;
}

bool TwoStacks::isSecondEmpty() const {
    return false;
}
