#include "OurGrid.h"
#include "error.h"
using namespace std;

OurGrid::OurGrid(int numRows, int numCols) {
    (void) numRows;
    (void) numCols;
}

OurGrid::~OurGrid() {

}

bool OurGrid::inBounds(int row, int col) const {
    (void) row;
    (void) col;
    return false;
}

int OurGrid::numRows() const {
    return -1;
}
int OurGrid::numCols() const {
    return -1;
}

int OurGrid::get(int row, int col) const {
    (void) row;
    (void) col;
    return -1;
}

void OurGrid::set(int row, int col, int value) {
    (void) row;
    (void) col;
    (void) value;
}
