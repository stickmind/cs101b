#include "Fraction.h"
#include "error.h"
#include <cmath>
using namespace std;

/* Constructs a new fraction. */
Fraction::Fraction(int numerator, int denominator) {
    /* Error-handling. */
    if (denominator == 0) {
        error("Division by zero.");
    }

    /* Stash the numerator and denominator. */
    num = numerator;
    den = denominator;

    /* Reduce to simplest form. */
    reduce();
}

int Fraction::numerator() const {
    return num;
}

int Fraction::denominator() const {
    return den;
}

void Fraction::add(const Fraction& f) {
    /* a/b + c/d = ad/bd + bc/bd = (ad + bc)/db */
    int nextNum = (numerator() * f.denominator()) + (denominator() * f.numerator());
    int nextDen = denominator() * f.denominator();

    /* Set these as the new numerator/denominator, then simplify. */
    num = nextNum;
    den = nextDen;
    reduce();
}

void Fraction::multiply(const Fraction& f) {
    /* A breath of fresh air compared to the ones above. >_< */
    num *= f.numerator();
    den *= f.denominator();
    reduce();
}

double Fraction::asDecimal() const {
    return double(numerator()) / denominator();
}

/* Reduces the fraction to its simplest form. This uses Euclid's algorithm to
 * compute the greatest common divisor (gcd) of the numerator and denominator,
 * then divides through by it.
 */
void Fraction::reduce() {
    int a = abs(numerator());
    int b = abs(denominator());

    while (b != 0) {
        int c = a % b;
        a = b;
        b = c;
    }

    /* a is now the gcd of the numerator and denominator. */
    num /= a;
    den /= a;

    /* Transfer sign to the numerator. */
    if (den < 0) {
        den *= -1;
        num *= -1;
    }
}
