#include "RingBufferQueue.h"
#include "error.h"
using namespace std;

/* Capacity of a RingBufferQueue. */
const int kNumSlots = 5; // Matches diagram above

RingBufferQueue::RingBufferQueue() {

}

RingBufferQueue::~RingBufferQueue() {

}

void RingBufferQueue::enqueue(int value) {
    (void) value;
}

int RingBufferQueue::peek() const {
    return -1;
}

int RingBufferQueue::dequeue() {
    return -1;
}

int RingBufferQueue::size() const {
    return -1;
}

bool RingBufferQueue::isEmpty() const {
    return false;
}
