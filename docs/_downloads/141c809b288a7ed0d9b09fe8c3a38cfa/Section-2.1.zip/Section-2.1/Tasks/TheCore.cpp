#include "TheCore.h"
using namespace std;

Set<string> kCoreOf(const Map<string, Set<string>>& network, int k) {
    (void) network;
    (void) k;
    return {};
}
