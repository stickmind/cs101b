/* * * * * Test Cases Below This Point * * * * */
#include "GUI/SimpleTest.h"
#include "Boustrophedon.h"
using namespace std;

PROVIDED_TEST("Works on a 2xn grid.") {
    Grid<char> chars = {
        { 'a', 'b', 'c' },
        { 'd', 'e', 'f' }
    };

    EXPECT_EQUAL(fromBoustrophedon(chars), "abcfed");
}

PROVIDED_TEST("Works on a 3xn grid.") {
    Grid<char> chars = {
        { 'a', 'b', 'c' },
        { 'd', 'e', 'f' },
        { 'g', 'h', 'i' }
    };

    EXPECT_EQUAL(fromBoustrophedon(chars), "abcfedghi");
}
