#include "NewOrgChart.h"
using namespace std;

bool areAtSameCompany(const string& p1,
                      const string& p2,
                      const Map<string, string>& bosses) {
    (void) p1;
    (void) p2;
    (void) bosses;
    return false;
}
