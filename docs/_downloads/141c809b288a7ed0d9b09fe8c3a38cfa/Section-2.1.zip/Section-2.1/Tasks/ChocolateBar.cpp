#include "ChocolateBar.h"
using namespace std;

int numWaysToEat(int numSquares) {
    (void) numSquares;
    return 0;
}

void printWaysToEat(int numSquares) {
    (void) numSquares;
}

Set<Vector<int>> waysToEat(int numSquares) {
    (void) numSquares;
    return {};
}
