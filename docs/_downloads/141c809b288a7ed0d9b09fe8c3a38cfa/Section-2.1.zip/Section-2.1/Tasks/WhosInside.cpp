#include "WhosInside.h"
using namespace std;

Set<int> peopleInsideGreen(const Vector<int>& idScans) {
    (void) idScans;
    return {};
}
