#include "Boustrophedon.h"
using namespace std;

string fromBoustrophedon(const Grid<char>& message) {
    (void) message;
    return "";
}
