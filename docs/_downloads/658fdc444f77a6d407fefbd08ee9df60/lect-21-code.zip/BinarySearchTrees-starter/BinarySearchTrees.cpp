/*****************************************************
 * File: BinarySearchTrees.cpp
 *
 * A program to play around with binary search trees!
 */
#include <iostream>
#include <string>
#include "console.h"
#include "simpio.h"
#include "TreeGraphics.h"
using namespace std;

/* Type: Node
 * A node in a binary search tree.
 */
struct Node {
    int value;
    Node* left;
    Node* right;
};

/* Constructs this specific BST:
 *
 *                    49
 *                  /    \
 *                 25    77
 *                /  \     \
 *               12  37    96
 *
 * This is NOT how you typically make a BST. Think of this like the original
 * code we saw that manually constructed a linked list - it's something to
 * get us started, but in practice you'd build the tree using other methods.
 */
Node* makeInitialTree() {
    return new Node {
        49,
        new Node {
            25,
            new Node {
                12, nullptr, nullptr
            },
            new Node {
                37, nullptr, nullptr
            }
        },
        new Node {
            77,
            nullptr,
            new Node {
                96, nullptr, nullptr
            }
        }
    };
}

/* TODO: Returns whether the given element is in the BST pointed at by
 * root.
 */
bool contains(Node* root, int key) {
    (void) root;
    (void) key;
    return false;
}

/* TODO: Prints all nodes in the BST in sorted order. */
void printTree(Node* root) {
    (void) root;
}

/* TODO: Adds the value to the given tree. */
void add(Node*& root, int key) {
    (void) root;
    (void) key;
    return;
}

int main() {
    /* Constructs this specific BST:
     *
     *                    49
     *                  /    \
     *                 25    77
     *                /  \     \
     *               12  37    96
     */
    Node* root = makeInitialTree();
    drawTree(root);

    printTree(root);

    while (true) {
        int value = getInteger("Enter value: ");
        if (contains(root, value)) {
            cout << "Yep! It's there." << endl;
        } else {
            cout << "Nope! Not there." << endl;
            add(root, value);
        }

        drawTree(root);
    }
}
