#include "Fire.h"
using namespace std;

void updateFire(Grid<int>& fire) {
    /* TODO: The next line just exists to make sure you don't get compiler warning messages
     * when this function isn't implemented. Delete this comment and the next line, then
     * implement this function.
     */
    (void) fire;
}
