/*
 * File: Trees.cpp
 * ---------------
 * A program that generates trees using recursion!
 */
#include <iostream>
#include <string>
#include "random.h"
#include "gwindow.h"
#include "gobjects.h"
#include "gthread.h"
using namespace std;

/* Draws a line from the position (x, y) of length 'length,'
 * in the direction given by angle. The function then returns
 * the endpoint of the line.
 */
GPoint drawPolarLine(double x, double y,
                     double length,
                     double angle);

/* Draws a tree in the given window where
 *
 *  1. The base of the tree is at (x, y),
 *  2. The height of the tree is (roughly) length,
 *  3. The tree grows at the given angle from its
 *     base, and
 *  4. The order of the tree is given by the order
 *     parameter.
 */
int drawTree(double x, double y,
             double length,
             double angle,
             int order) {
    /* Base case: An order-0 tree is nothing at all. */
    if (order == 0) {
        return 0;
    }

    int numLines = 0;

    // Draw the trunk
    GPoint endpoint = drawPolarLine(x, y,
                                    length * 0.33,
                                    angle);
    numLines++;

    // Draw two smaller trees.
    // Feel free to tinker with the constants here,
    // or to add randomness, or to add more trees,
    // etc.
    numLines += drawTree(endpoint.x, endpoint.y,
                         length * 0.73,
                         angle + 20,
                         order - 1);
    numLines += drawTree(endpoint.x, endpoint.y,
                         length * 0.64,
                         angle - 45,
                         order - 1);

    return numLines;
}

/* Constants controlling the window size. */
const double kWindowWidth = 1000;
const double kWindowHeight = 600;

/* Ewww, global variables! You aren't allowed to use these.
 * We are, but just for this one demo. :-)
 */
GWindow* theWindow;

/* Graphics routines to clear the screen and redraw everything all at once. */
void clear();
void repaintWindow();

/* Main program */
int main() {
    GWindow window(kWindowWidth, kWindowHeight);
    window.setColor("Black");
    window.setExitOnClose(true);
    window.setTitle("Trees!");
    theWindow = &window;

    /* Keep drawing trees! */
    while (true) {
        clear();

        /* Position the tree at the bottom of the window. */
        double treeRootX  = window.getCanvasWidth()  / 2.0;
        double treeRootY  = window.getCanvasHeight();
        double treeHeight = window.getCanvasHeight();

        /* The code above this does some graphics-y
         * things to get everything set up.
         */

        int numLines = drawTree(treeRootX, treeRootY,
                                treeHeight,
                                90.0, 8);
        cout << "Lines in that tree: " << numLines << endl;
        pause(2000);
    }
}

/* * * * * Graphics logic below this point * * * * */

/* This somewhat clunky-looking function is
 * designed to repaint the window immediately
 * so that if we step through this code in
 * the debugger, the window is responsive and
 * shows the lines we're drawing. This is basically
 * a hack around our libraries; you aren't
 * expected to understand how this works.
 */
void repaintWindow() {
    GThread::runOnQtGuiThread([] {
        theWindow->repaint();
    });
}

/* Clears the graphics contents from the window. */
void clear() {
    theWindow->clearCanvasPixels();
    repaintWindow();
}

/* This is a modified version of drawPolarLine that is
 * specifically designed to play nicely with the debugger.
 * You aren't expected to understand how this works.
 */
GPoint drawPolarLine(double x, double y,
                     double length,
                     double angle) {
    GPoint result = theWindow->drawPolarLine(x, y, length, angle);
    repaintWindow();
    return result;
}
