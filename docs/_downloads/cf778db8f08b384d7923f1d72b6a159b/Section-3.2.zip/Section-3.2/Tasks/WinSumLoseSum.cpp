#include "WinSumLoseSum.h"
using namespace std;

Set<int> numbersMadeFrom(const Set<int>& values) {
    (void) values;
    return {};
}

bool canMakeTarget(const Set<int>& values, int target) {
    (void) values;
    (void) target;
    return false;
}
