#include "MmmPancakes.h"
using namespace std;

Optional<Vector<int>> sortStack(Stack<double> pancakes, int numFlips) {
    (void) pancakes;
    (void) numFlips;
    return Nothing;
}
