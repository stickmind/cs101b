#pragma once

#include "set.h"

Set<int> numbersMadeFrom(const Set<int>& values);
bool canMakeTarget(const Set<int>& values, int target);
