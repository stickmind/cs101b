#include "AllSquaredAway.h"
using namespace std;

Optional<Vector<int>> findSquareSequence(int n) {
    (void) n;
    return Nothing;
}
