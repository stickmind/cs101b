#include "WeightsAndBalances.h"
using namespace std;

bool isMeasurable(int amount, const Vector<int>& weights) {
    (void) amount;
    (void) weights;
    return false;
}
