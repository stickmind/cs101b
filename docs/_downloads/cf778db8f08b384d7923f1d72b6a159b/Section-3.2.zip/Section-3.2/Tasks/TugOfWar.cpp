#include "TugOfWar.h"
using namespace std;

bool canSplitEvenly(const Vector<int>& strengths) {
    (void) strengths;
    return false;
}
