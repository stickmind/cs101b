/*****************************************************
 * File: RangeSearches.cpp
 *
 * Code to perform range searches over a BST.
 */
#include <iostream>
#include <string>
#include <iomanip>
#include "TreeGraphics.h"
#include "vector.h"
#include "console.h"
#include "simpio.h"
using namespace std;

/* Type: Node
 * A node in a binary search tree.
 */
struct Node {
    string value;
    Node* left;
    Node* right;
};

/* All the USPS abbreviations. */
const Vector<string> kUSPSCodes = {
    "UT", "KY", "AK", "IL", "LA",
    "FL", "AL", "MN", "NH", "VI",
    "MI", "WA", "MS", "TN", "RI",
    "MT", "DE", "NV", "ND", "NC",
    "WI", "NE", "MA", "HI", "NM",
    "IA", "CT", "WV", "OR", "ID",
    "KS", "MO", "GA", "SD", "VT",
    "AZ", "CO", "OK", "WY", "VA",
    "NY", "NJ", "SC", "PA", "TX",
    "PR", "AR", "ME", "CA", "DC",
    "MD", "IN", "OH"
};

void insertInto(Node*& root, const string& key) {
    /* Base case: If we insert into an empty tree, just make a new node for the key. */
    if (root == nullptr) {
        root = new Node { key, nullptr, nullptr };
    }
    /* Otherwise, see where we go. */
    else if (key < root->value) {
        insertInto(root->left, key);
    } else if (key > root->value) {
        insertInto(root->right, key);
    } /* else if (key == root->value) // do nothing */
}

/* Build a tree of all USPS codes. */
Node* americanTree() {
    Node* root = nullptr;
    for (string element: kUSPSCodes) {
        insertInto(root, element);
    }
    return root;
}

/* Print all values in the tree that are greater than or equal to 'low'
 * and less than or equal to 'high'.
 */
void printInRange(Node* root, const string& low, const string& high) {
    /* Empty tree? Then there's nothing here. */
    if (root == nullptr) {
        return;
    }

    /* If this node is out of the range, you only need to look at
     * the subtree that is closer to that range.
     */
    if (high < root->value) {
        printInRange(root->left, low, high);
    } else if (root->value < low) {
        printInRange(root->right, low, high);
    }
    /* Otherwise, you're in range, and the left and right subtrees
     * might each have something to contribute too.
     */
    else {
        printInRange(root->left, low, high);
        cout << root->value << endl;
        printInRange(root->right, low, high);
    }
}

int main() {
    Node* root = americanTree();
    drawTree(root);

    while (true) {
        string low  = getLine("From: ");
        string high = getLine("To:   ");
        printInRange(root, low, high);
    }
    return 0;
}
